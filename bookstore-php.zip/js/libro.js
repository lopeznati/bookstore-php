$(document).ready(function(){

	//swal("Here's a message!");
	$("#cartelLibro").click(function(otro){
		
		alert("hola");
		
	});
})

