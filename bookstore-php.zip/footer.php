<footer class="container-fluid text-center">
    <p style='font-size: 12px;'><?php echo include_once 'ws.php' ?></p>
</footer>